package com.nquantum.module;

public enum Category {
    COMBAT, MOVEMENT, RENDER, PLAYER, MISC, EXPLOIT, NONE
}
